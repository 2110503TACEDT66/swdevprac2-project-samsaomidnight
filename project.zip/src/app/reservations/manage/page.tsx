export default function ManageReservation() {
    return (
        <main>
            <div className="text-center text-2xl font-semibold font-serif py-8">
                Manage Your Appointment
            </div>
        </main>
    );
}