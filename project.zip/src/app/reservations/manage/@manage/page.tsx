export default function ManagePage() {
    return (
        <main>
            {/* <div>Your Appointments</div> */}
        </main>
    )
}

//no need