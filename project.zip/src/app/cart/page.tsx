'use client'
import ReservationCart from "@/components/ReservationCart"

export default function CartPage() {
    return (
        <main>
            <ReservationCart></ReservationCart>
        </main>
    )
}